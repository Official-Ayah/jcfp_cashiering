-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2024 at 12:56 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cashiering`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    description VARCHAR(255),
    category VARCHAR(100),
    amount DECIMAL(10,2),
    image VARCHAR(255),
    date DATETIME,
    views INT DEFAULT 0
);

INSERT INTO products (id, user_id, description, category, amount, image, date, views) VALUES
(1, NULL, 'Salted Caramel', 'Classic Milkteas', 49.00, 'salted_caramel.jpg', '2025-03-11 23:44:04', 0),
(2, NULL, 'Chocolate', 'Classic Milkteas', 49.00, 'chocolate_milktea.jpg', '2025-03-11 23:44:04', 0),
(3, NULL, 'Strawberry', 'Classic Milkteas', 49.00, 'strawberry.jpg', '2025-03-11 23:44:04', 0),
(4, NULL, 'Honeydew', 'Classic Milkteas', 49.00, 'honey_dew.jpg', '2025-03-11 23:44:04', 0),
(5, NULL, 'Matcha', 'Classic Milkteas', 49.00, 'matcha.jpg', '2025-03-11 23:44:04', 0),
(6, NULL, 'Lychee', 'Fruit Teas', 49.00, 'lychee_fruit.jpg', '2025-03-11 23:44:04', 0),
(7, NULL, 'Strawberry', 'Fruit Teas', 49.00, 'strawberry_fruit.jpg', '2025-03-11 23:44:04', 0),
(8, NULL, 'Green Apple', 'Fruit Teas', 49.00, 'green_apple.jpg', '2025-03-11 23:44:04', 0),
(9, NULL, 'JC Cheesecake', 'Special Series', 89.00, 'jc.jpg', '2025-03-11 23:44:04', 0),
(10, NULL, 'Oreo Cheesecake', 'Special Series', 89.00, 'oreo.jpg', '2025-03-11 23:44:04', 0),
(11, NULL, 'Graham Cheesecake', 'Special Series', 89.00, 'graham_cheesecake.jpg', '2025-03-11 23:44:04', 0),
(12, NULL, 'Dark Choco Nutella', 'Special Series', 89.00, 'dark_nutella.jpg', '2025-03-11 23:44:04', 0),
(13, NULL, 'Oreo Nutella', 'Special Series', 89.00, 'oreo_nutella.jpg', '2025-03-11 23:44:04', 0),
(14, NULL, 'Fries Solo', 'Bar Snacks', 75.00, 'fries_solo.jpg', '2025-03-11 23:44:04', 0),
(15, NULL, 'Fries Sharing', 'Bar Snacks', 105.00, 'fries.jpg', '2025-03-11 23:44:04', 0),
(16, NULL, 'Amerikano', 'Cold Coffee', 49.00, 'amerikano.jpg', '2025-03-11 23:58:13', 0),
(17, NULL, 'White Chocolate Mocha', 'Cold Coffee', 49.00, 'white_chocomocha.jpg', '2025-03-11 23:58:13', 0),
(18, NULL, 'Mocha', 'Cold Coffee', 49.00, 'mocha.jpg', '2025-03-11 23:58:13', 0),
(19, NULL, 'Spanish Latte', 'Cold Coffee', 49.00, 'spanish_latte.jpg', '2025-03-11 23:58:13', 0),
(20, NULL, 'Dirty Matcha', 'Cold Coffee', 49.00, 'dirty_matcha.jpg', '2025-03-11 23:58:13', 0),
(21, NULL, 'Choco Milk', 'Milk-Based', 49.00, 'choco_milk.jpg', '2025-03-11 23:58:13', 0),
(22, NULL, 'Matcha', 'Milk-Based', 59.00, 'matcha_milk.jpg', '2025-03-11 23:58:13', 0),
(23, NULL, 'Matcha Berry', 'Milk-Based', 59.00, 'matcha_berry.jpg', '2025-03-11 23:58:13', 0);
(24, NULL, 'Strawberry', 'Milk-Based', 49.00, 'strawberry_milk.jpg', '2025-03-11 23:58:13', 0),
(25, NULL, 'Lemon', 'Soda-Based', 49.00, 'lemon_soda.jpg', '2025-03-11 23:58:13', 0);
(26, NULL, 'Green Apple', 'Soda-Based', 49.00, 'green_soda.jpg', '2025-03-11 23:58:13', 0),
(27, NULL, 'Strawberry', 'Soda-Based', 49.00, 'strawberry_soda.jpg', '2025-03-11 23:58:13', 0),
(28, NULL, 'Blueberry', 'Soda-Based', 49.00, 'blueberry_soda.jpg', '2025-03-11 23:58:13', 0),
(29, NULL, 'Taro', 'Classic Milkteas', 49.00, '1741744633_taro.jpg', '2025-03-12 09:57:13', 0);

-- --------------------------------------------------------

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `receipt_no` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `date` datetime NOT NULL,
  `user_id` varchar(60) NOT NULL,
  `transaction_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--

INSERT INTO `sales` (`id`, `receipt_no`, `description`, `qty`, `amount`, `total`, `date`, `user_id`, `transaction_no`) VALUES
(61, 43, 'Salted Caramel', 2, 49.00, 98.00, '2025-03-12 10:00:00', 1, '202503120001'),
(62, 44, 'Matcha', 1, 49.00, 49.00, '2025-03-12 10:05:00', 2, '202503120002'),
(63, 45, 'JC Cheesecake', 3, 89.00, 267.00, '2025-03-12 10:10:00', 3, '202503120003'),
(64, 46, 'Fries Sharing', 2, 105.00, 210.00, '2025-03-12 10:15:00', 4, '202503120004'),
(65, 47, 'Matcha Berry', 1, 59.00, 59.00, '2025-03-12 10:20:00', NULL, '202503120005'),
(66, 48, 'Lemon Soda', 4, 49.00, 196.00, '2025-03-12 10:30:00', 5, '202503120006'),
(67, 49, 'Blueberry Soda', 2, 49.00, 98.00, '2025-03-12 10:40:00', 6, '202503120007');

-- -------------------------------------------------------- 

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    email VARCHAR(255),
    password VARCHAR(255),
    date DATETIME,
    image VARCHAR(255) DEFAULT NULL,
    role VARCHAR(50),
    gender VARCHAR(10),
    deletable TINYINT(1)
);

INSERT INTO users (id, username, email, password, date, image, role, gender, deletable) VALUES
(2, 'Kriezyl Villalobos', 'krieZyl@gmail.com', 'KrieZyl907', '2024-09-07 12:42:11', NULL, 'admin', 'female', 1),
(8, 'Sydney Magsalay', 'sydney@gmail.com', 'Sydney923', '2024-09-23 10:56:42', NULL, 'cashier', 'female', 1),
(9, 'Jiselle Maramba', 'jiselle@gmail.com', 'Jiselle924', '2024-09-24 21:48:28', NULL, 'supervisor', 'female', 1),
(11, 'Norcaya Pacaambung', 'norcaya@gmail.com', 'Norcaya221', '2025-02-21 20:17:04', NULL, 'cashier', 'female', 1);

-- --------------------------------------------------------

ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `description` (`description`),
  ADD KEY `qty` (`qty`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`),
  ADD KEY `views` (`views`);

--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `receipt_no` (`receipt_no`),
  ADD KEY `date` (`date`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `description` (`description`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `date` (`date`),
  ADD KEY `role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
