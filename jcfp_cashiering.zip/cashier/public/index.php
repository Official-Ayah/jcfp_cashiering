<?php

session_start();

define("ABSPATH", true);

require "../app/core/init.php";

$controller = $_GET['page_name'] ?? "home";
$controller = strtolower($controller);

// Check if the controller file exists
if (file_exists("../app/controllers/" . $controller . ".php")) {
    require "../app/controllers/" . $controller . ".php";
} else {
    echo "Controller not found: " . htmlspecialchars($controller);
}
?>
