<?php

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user = new User();
    if ($row = $user->where(['email' => $_POST['email']])) {

        if ($_POST['password'] === $row[0]['password']) {
            authenticate($row[0]);

            // Check user role and redirect accordingly
            if ($row[0]['role'] === 'admin') {
                redirect('admin');
            } else {
                redirect('home');
            }
        } else {
            $errors['password'] = "Wrong password";
        }
        
    } else {
        $errors['email'] = "Wrong email";
    }
}

require views_path('auth/login');
?>