<?php

defined("ABSPATH") ? "" : die();

// Function to generate unique transaction number
function generate_transaction_no() {
    $db = new Database();
    $date = date("Y-m-d");

    // Fetch the last transaction number for the current date
    $query = "SELECT transaction_no FROM sales WHERE DATE(date) = :date ORDER BY transaction_no DESC LIMIT 1";
    $lastTransaction = $db->query($query, ['date' => $date]);

    if (empty($lastTransaction)) {
        // If no transactions found, start from 1
        return date("Ymd") . "0001"; // Format: YYYYMMDD0001
    }

    $lastTransactionNo = $lastTransaction[0]['transaction_no'];
    // Increment the last transaction number
    $incrementedNo = intval(substr($lastTransactionNo, -4)) + 1; // Get the last 4 digits and increment

    // Generate the new transaction number with leading zeros
    return date("Ymd") . str_pad($incrementedNo, 4, '0', STR_PAD_LEFT);
}

$raw_data = file_get_contents("php://input");
if (!empty($raw_data)) {
    $OBJ = json_decode($raw_data, true);

    if (is_array($OBJ)) {
        if ($OBJ['data_type'] == "search") {
            $productClass = new Product();
            $limit = 20;

            if (!empty($OBJ['text'])) {
                $text = "%" . $OBJ['text'] . "%";
                $query = "SELECT * FROM products WHERE description LIKE :find LIMIT 20";
                $rows = $productClass->query($query, ['find' => $text]);
            } else {
                // Get all products sorted by views
                $rows = $productClass->getAll($limit, 0, 'desc', 'views');
            }

            if ($rows) {
                foreach ($rows as $key => $row) {
                    $rows[$key]['description'] = strtoupper($row['description']);

                    // Correct image path
                    if (!empty($row['image'])) {
                        $rows[$key]['image'] = "uploads/" . $row['image'];
                    } else {
                        $rows[$key]['image'] = "uploads/no_image.jpg"; // Default image if missing
                    }
                }

                $info['data_type'] = "search";
                $info['data'] = $rows;

                echo json_encode($info);
                exit;
            }
        }
       
        else if ($OBJ['data_type'] == "checkout") {
            $data = $OBJ['text']; // Fix: Now correctly reading the cart items
        
            $receipt_no = get_receipt_no();
            $transaction_no = generate_transaction_no(); // Generate a unique transaction number
            $user_id = auth("id");
            $date = date("Y-m-d H:i:s");
            $db = new Database();
        
            $total = 0; // Track total amount
        
            foreach ($data as $row) {
                $arr = [];
                $arr['id'] = $row['id'];
                $query = "SELECT * FROM products WHERE id = :id LIMIT 1";
                $check = $db->query($query, $arr);
        
                if (is_array($check)) {
                    $check = $check[0];
        
                    // Compute total per item
                    $item_total = $row['qty'] * $check['amount'];
                    $total += $item_total; // Add to total
        
                    // Save to sales table
                    $arr = [];
                    $arr['description'] = $check['description'];
                    $arr['amount'] = $check['amount'];
                    $arr['qty'] = $row['qty'];
                    $arr['total'] = $item_total;
                    $arr['receipt_no'] = $receipt_no;
                    $arr['transaction_no'] = $transaction_no;
                    $arr['date'] = $date;
                    $arr['user_id'] = $user_id;
        
                    $query = "INSERT INTO sales (receipt_no, transaction_no, description, qty, amount, total, date, user_id) 
                              VALUES (:receipt_no, :transaction_no, :description, :qty, :amount, :total, :date, :user_id)";
                    $db->query($query, $arr);
    
        
                    // Increase product views
                    $query = "UPDATE products SET views = views + 1 WHERE id = :id LIMIT 1";
                    $db->query($query, ['id' => $check['id']]);
                }   
            }
        
            // Get payment details
            $amountPaid = $OBJ['amountPaid'];
            $change = $amountPaid - $total;
        
            $info['data_type'] = "checkout";
            $info['message'] = "Sale recorded successfully!";
            echo json_encode($info);
            exit;
        }
    }
}        
?>