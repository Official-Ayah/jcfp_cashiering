<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$tab = $_GET['tab'] ?? 'dashboard';

// Ensure role is set
if (!isset($_SESSION['role'])) {
    $_SESSION['role'] = 'guest'; // Default role if not logged in
}

// Initialize variables to prevent "Undefined Variable" errors
$total_users = 0;
$total_products = 0;
$total_sales = 0;
$sales_total = 0;

if ($tab == "products") {
    $productClass = new Product();
    $products = $productClass->query("SELECT * FROM products ORDER BY id DESC");
} 
else if ($tab == "sales") {
    if ($_SESSION['role'] === 'admin') {
        Auth::setMessage("Admins cannot access the checkout system");
        require views_path('auth/denied');
        exit();
    }

    $section = $_GET['s'] ?? 'table';
    $startdate = $_GET['start'] ?? null;
    $enddate = $_GET['end'] ?? null;

    $saleClass = new Sale();
    $limit = 10;
    $pager = new Pager($limit);
    $offset = $pager->offset;

    $query = "SELECT * FROM sales ORDER BY id DESC LIMIT $limit OFFSET $offset";
    $query_total = "SELECT SUM(total) AS total FROM sales WHERE DAY(date) = DAY(NOW()) 
                    AND MONTH(date) = MONTH(NOW()) AND YEAR(date) = YEAR(NOW())";

    if ($startdate && $enddate) {
        $query = "SELECT * FROM sales WHERE date BETWEEN '$startdate' AND '$enddate' 
                  ORDER BY id DESC LIMIT $limit OFFSET $offset";
        $query_total = "SELECT SUM(total) AS total FROM sales WHERE date BETWEEN '$startdate' AND '$enddate'";
    } 
    else if ($startdate) {
        $query = "SELECT * FROM sales WHERE DATE(date) = '$startdate' 
                  ORDER BY id DESC LIMIT $limit OFFSET $offset";
        $query_total = "SELECT SUM(total) AS total FROM sales WHERE DATE(date) = '$startdate'";
    }

    $sales = $saleClass->query($query);
    $st = $saleClass->query($query_total);
    $sales_total = $st[0]['total'] ?? 0;
} 
else if ($tab == "users") {
    $userClass = new User();
    $users = $userClass->query("SELECT * FROM users ORDER BY id DESC");
} 
else if ($tab == "dashboard") {
    $db = new Database();

    $query = "SELECT COUNT(id) AS total FROM users";
    $myusers = $db->query($query);
    $total_users = $myusers[0]['total'] ?? 0;

    $query = "SELECT COUNT(id) AS total FROM products";
    $myproducts = $db->query($query);
    $total_products = $myproducts[0]['total'] ?? 0;

    $query = "SELECT SUM(total) AS total FROM sales";
    $mysales = $db->query($query);
    $total_sales = $mysales[0]['total'] ?? 0;
}

// Check admin access
if (Auth::access('supervisor')) {
    require views_path('admin/admin');
} 
else {
    Auth::setMessage("You don't have access to the admin page");
    require views_path('auth/denied');
}

// Checkout confirmation before printing receipt
if ($tab == "checkout") {
    echo '<script>
        if (confirm("Do you want to confirm this order?")) {
            window.print(); // Print the receipt
        }
    </script>';
}
