<?php
if (!defined("ABSPATH")) {
    die("Direct access not allowed");
}

// Get transaction number from URL
$transaction_no = $_GET['id'] ?? null;

if ($transaction_no) {
    // Database connection
    $db = new Database();

    // Fetch order details
    $query = "SELECT * FROM sales WHERE transaction_no = :transaction_no";
    $orders = $db->query($query, ['transaction_no' => $transaction_no]);

    if ($orders) {
        $total_amount = 0; // Initialize total amount
        ?>
        <h2>Order Details for Transaction #<?= htmlspecialchars($transaction_no) ?></h2>
        <table border="1">
            <tr>
                <th>Receipt No</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Amount</th>
                <th>Total</th>
            </tr>
            <?php foreach ($orders as $order): 
                $total_amount += $order['total']; // Add to total amount
            ?>
            <tr>
                <td><?= htmlspecialchars($order['receipt_no']) ?></td>
                <td><?= htmlspecialchars($order['description']) ?></td>
                <td><?= htmlspecialchars($order['qty']) ?></td>
                <td><?= htmlspecialchars($order['amount']) ?></td>
                <td><?= htmlspecialchars($order['total']) ?></td>
            </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="4" align="right"><strong>Grand Total:</strong></td>
                <td><strong><?= htmlspecialchars(number_format($total_amount, 2)) ?></strong></td>
            </tr>
        </table>
        <?php
    } else {
        echo "<p>No orders found for this transaction.</p>";
    }
} else {
    echo "<p>Transaction number is required.</p>";
}
?>
