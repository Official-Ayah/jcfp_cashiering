<?php if($section == 'table'): ?>

<div class="filter-form">
    <form class="row float-end" action="index.php?page_name=admin&tab=sales" method="GET">
        <div class="col">
            <label for="start">Start Date:</label>
            <input class="form-control" id="start" type="date" name="start" value="<?= esc($_GET['start'] ?? '') ?>">
        </div>
        <div class="col">
            <label for="end">End Date:</label>
            <input class="form-control" id="end" type="date" name="end" value="<?= esc($_GET['end'] ?? '') ?>">
        </div>
        <button class="btn btn-filter" type="submit">Go</button>
        <input type="hidden" name="page_name" value="admin">
        <input type="hidden" name="tab" value="sales">
    </form>
    <div class="clearfix"></div>
</div>

<h2>Today's Total: ₱ <?= number_format($sales_total, 2) ?></h2>

<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Transaction No.</th>
                <th>Receipt No.</th>
                <th>Description</th>
                <th>QTY</th>
                <th>Amount</th>
                <th>Total</th>
                <th>Cashier</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($sales)): ?>
                <?php 
                $previous_transaction_no = null;
                $color_switch = 1; // Toggle for alternating row colors
                $transaction_total = 0;
                foreach ($sales as $index => $sale): 
                    $is_first_item_transaction = ($sale['transaction_no'] !== $previous_transaction_no);
                    if ($is_first_item_transaction && $previous_transaction_no !== null): ?>
                        <tr class="transaction-group-<?= $color_switch ?>">
                            <td colspan="5" style="text-align: right;"><strong>Total:</strong></td>
                            <td><?= number_format($transaction_total, 2) ?></td>
                            <td colspan="2"></td>
                        </tr>
                    <?php 
                        $transaction_total = 0;
                        $color_switch = ($color_switch == 1) ? 2 : 1;
                    endif;
                    $transaction_total += $sale['total'];
                ?>
                    <tr class="transaction-group-<?= $color_switch ?>">
                        <td><?= $is_first_item_transaction ? esc($sale['transaction_no']) : '' ?></td>
                        <td><?= $is_first_item_transaction ? esc($sale['receipt_no']) : '' ?></td>
                        <td><?= esc($sale['description']) ?></td>
                        <td><?= esc($sale['qty']) ?></td>
                        <td><?= number_format(esc($sale['amount']), 2) ?></td>
                        <td><?= number_format(esc($sale['total']), 2) ?></td>
                        <?php if ($is_first_item_transaction): ?>
                            <?php
                            $cashier = get_user_by_id($sale['user_id']);
                            $name = empty($cashier) ? "Unknown" : esc($cashier['username']);
                            $namelink = empty($cashier) ? "#" : "index.php?pg=profile&id=" . esc($cashier['id']);
                            ?>
                            <td><a href="<?= $namelink ?>"><?= $name ?></a></td>
                            <td><?= date("jS M, Y", strtotime($sale['date'])) ?></td>
                            <td>
                            <a href="index.php?page_name=get_order_details&id=<?= $sale['transaction_no'] ?>">View Order</a>
                            </td>
                        <?php else: ?>
                            <td></td>
                            <td></td>
                        <?php endif; ?>
                    </tr>
                <?php 
                    $previous_transaction_no = $sale['transaction_no'];
                endforeach; 
                ?>
                <tr class="transaction-group-<?= $color_switch ?>">
                    <td colspan="5" style="text-align: right;"><strong>Total:</strong></td>
                    <td><?= number_format($transaction_total, 2) ?></td>
                    <td colspan="2"></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="no-sales">No sales records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-center mt-3">
        <?php $pager->display(); ?>
    </div>    
</div>

<?php endif; ?>
