<style>
  /* General Styling */
.stat-card {
    border: none; /* Remove solid border */
    border-radius: 12px;
    padding: 25px;
    margin: 15px;
    text-align: center;
    background: linear-gradient(135deg, #f9f9f9, #f1f1f1); /* Soft gradient background */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth hover effect */
    text-decoration: none; /* Remove underline from link */
    color: inherit; /* Inherit text color */
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

/* Hover Effect */
.stat-card:hover {
    transform: scale(1.05); /* Slight scale effect */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Stronger shadow */
}

/* Heading Styling */
.stat-card h4 {
    color: #444; /* Darker text for better contrast */
    font-size: 1.2rem;
    margin-bottom: 8px;
    font-weight: 600;
}

/* Number Styling */
.stat-card h1 {
    color: #222; /* Darker color for numbers */
    font-size: 2.8rem; /* Larger font size */
    font-weight: bold;
    margin: 0;
}

/* Icon Styling */
.stat-card i {
    color: #6f4c3e; /* Soft brown tone */
    font-size: 35px; /* Slightly larger */
    margin-bottom: 12px;
    transition: color 0.3s ease;
}

/* Icon Hover Effect */
.stat-card:hover i {
    color: #8b5e3c; /* Slightly darker brown on hover */
}

/* Responsive Grid */
@media (max-width: 992px) {
    .stat-card {
        width: 90%; /* Make cards take full width */
        margin: 10px auto; /* Center them */
    }
}

@media (max-width: 576px) {
    .stat-card h1 {
        font-size: 2.2rem; /* Reduce number size */
    }
    .stat-card i {
        font-size: 30px; /* Adjust icon size */
    }
}

</style>

<div class="row justify-content-center">
    <!-- Total Users card clickable -->
    <a href="index.php?page_name=admin&tab=users" class="col-md-3 stat-card shadow">
        <i class="fa fa-user" style="font-size: 30px"></i>
        <h4>Total Users:</h4>
        <h1><?=$total_users?></h1>
    </a>
    
    <!-- Total Drinks card clickable -->
    <a href="index.php?page_name=admin&tab=products" class="col-md-3 stat-card shadow">
        <i class="fa fa-box-open" style="font-size: 30px"></i>
        <h4>Total Products:</h4>
        <h1><?=$total_products?></h1>
    </a>
    
    <!-- Total Sales card clickable -->
    <a href="index.php?page_name=admin&tab=sales" class="col-md-3 stat-card shadow">
        <i class="fa fa-money-bill-wave" style="font-size: 30px"></i>
        <h4>Total Sales:</h4>
        <h1>₱ <?=$total_sales?></h1>
    </a>
</div>
