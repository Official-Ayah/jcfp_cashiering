<style>
   /* General Body Styling */
body {
    font-family: 'Arial', sans-serif;
    background-color:#654321;
    color:#6b4226;
}

/* Table Container */
.table-responsive {
    margin: 20px auto;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
    background-color: #ffffff;
    padding: 15px;
}

/* Table Styling */
.table {
    width: 100%;
    border-collapse: collapse;
}

/* Table Header */
.table th {
    background-color: #e9967a;
    color: #ffffff;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 16px;
}

/* Table Body Rows */
.table td {
    padding: 14px;
    text-align: center;
    font-size: 1rem;
}

/* Striped Rows */
.table-striped tbody tr:nth-of-type(odd) {
    background-color: #fdf6f0;
}

/* Row Hover Effect */
.table-striped tbody tr:hover {
    background-color: #e5d1bc;
    transition: background-color 0.3s ease;
}

/* Product Image Styling */
.product-image {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 5px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
    transition: transform 0.3s ease;
}

/* Image Hover Effect */
.product-image:hover {
    transform: scale(1.1);
}

/* No Products Message */
.no-products {
    text-align: center;
    color: #777;
    font-style: italic;
    padding: 20px;
}

/* Button Base Styling */
.btn {
    margin: 5px;
    border-radius: 6px;
    padding: 8px 14px;
    font-size: 0.95rem;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

/* Add Product Button */
.btn-add-product {
    background-color: #ffdab9 !important;
    color: black !important;
    border: none;
    padding: 8px 14px;
    border-radius: 6px;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.btn-add-product:hover {
    background-color: #f4a460 !important;
    transform: translateY(-3px);
}

/* Edit Button */
.btn1 {
    background-color: #ffff66; /* Yellow */
    color: black;
}

.btn1:hover {
    background-color: rgb(254, 255, 185);
    transform: translateY(-3px);
}

/* Delete Button */
.btn-danger {
    background-color: red;
    color: white;
}

.btn-danger:hover {
    background-color: #b43a2e;
    transform: translateY(-3px);
}

/* Table Header for Small Screens */
@media (max-width: 768px) {
    .table th {
        font-size: 0.9rem;
        padding: 12px;
    }
}

/* Responsive Table Adjustments */
@media (max-width: 576px) {
    .table-responsive {
        padding: 10px;
        box-shadow: none;
    }

    .table th, .table td {
        font-size: 0.85rem;
        padding: 10px;
    }

    .product-image {
        width: 60px;
        height: 60px;
    }
}

</style>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center" style="color:rgb(0, 0, 0);">Product List</h2>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Date</th>
                            <th>
                                <a href="index.php?page_name=products-new">
                                    <button class="btn btn-add-product btn-sm"><i class="fa fa-plus"></i> Add Product</button>
                                </a>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($products)): ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>
                                        <a href="index.php?page_name=product-single&id=<?=$product['id']?>" style="color:rgb(0, 0, 0); text-decoration: none;">
                                            <?=esc($product['description'])?>
                                        </a>
                                    </td>
                                    <td><?=esc($product['category'])?></td>
                                    <td><?=esc($product['amount'])?></td>
                                    <td>
                                        <img src="uploads/<?=esc($product['image'])?>" class="product-image" alt="<?=esc($product['description'])?>">
                                    </td>
                                    <td><?=date("jS M, Y H:i:s a", strtotime($product['date']))?></td>
                                    <td>
                                        <a href="index.php?page_name=products-edit&id=<?=$product['id']?>"><button class="btn btn1 btn-sm">Edit</button></a>
                                        <a href="index.php?page_name=products-delete&id=<?=$product['id']?>"><button class="btn btn-danger btn-sm">Delete</button></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="no-products">No products found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
