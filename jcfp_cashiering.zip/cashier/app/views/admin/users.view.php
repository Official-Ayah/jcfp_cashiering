<style>
    /* Container Styling */
.card-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center; /* Center cards */
    gap: 20px;
    margin: 20px 0;
}

/* User Card Styling */
.user-card {
    background: linear-gradient(135deg, #fff, #f8f8f8); /* Soft gradient */
    border: 2px solid #6f4c3e;
    border-radius: 12px;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    padding: 25px;
    width: calc(33.333% - 40px);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* Hover Effect */
.user-card:hover {
    transform: scale(1.05);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

/* Profile Image */
.user-card img {
    border-radius: 50%;
    object-fit: cover;
    width: 110px;
    height: 110px;
    border: 3px solid #6f4c3e;
    padding: 3px;
    transition: transform 0.3s ease;
}

/* Image Hover Effect */
.user-card:hover img {
    transform: scale(1.1);
}

/* Username Link */
.user-card h4 {
    margin: 12px 0 6px;
    font-size: 1.2rem;
    font-weight: bold;
}

.user-card h4 a {
    color: #6f4c3e;
    text-decoration: none;
    transition: color 0.3s ease;
}

.user-card h4 a:hover {
    color: #4e342e;
}

/* User Info Styling */
.user-card p {
    margin: 5px 0;
    color: #555;
    font-size: 0.95rem;
}

/* Button Styling */
.btn {
    margin: 5px;
    border-radius: 6px;
    padding: 7px 12px;
    font-size: 0.9rem;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

/* Edit Button */
.btn-success {
    background-color: #6f4c3e;
    border: none;
    color: white;
}

.btn-success:hover {
    background-color: #5a3c31;
    transform: scale(1.05);
}

/* Delete Button */
.btn-danger {
    background-color: #d9534f;
    border: none;
    color: white;
}

.btn-danger:hover {
    background-color: #c12a2a;
    transform: scale(1.05);
}

/* Create User Button */
.create-user-container {
    text-align: right;
    margin-bottom: 20px;
    margin-top: 8px;
}

.create-user-container a {
    color: white;
    font-weight: 600;
    padding: 10px 20px;
    background-color: #6f4c3e;
    border: 2px solid #6f4c3e;
    border-radius: 6px;
    text-decoration: none;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

/* Create User Button Hover */
.create-user-container a:hover {
    background-color: #5a3c31;
    transform: scale(1.05);
}

/* Responsive Design */
@media (max-width: 992px) {
    .user-card {
        width: calc(50% - 30px); /* Two columns on medium screens */
    }
}

@media (max-width: 576px) {
    .user-card {
        width: 100%; /* Full width on small screens */
    }

    .user-card h1 {
        font-size: 1.8rem;
    }
}

</style>

<div class="create-user-container">
    <?php if(Auth::access('admin')): ?>
        <a href="index.php?page_name=signup">Create a user</a>
    <?php endif; ?>
</div>

<div class="card-container">
    <?php if (!empty($users)): ?>
        <?php foreach ($users as $user): ?>
            <div class="user-card">
                <a href="index.php?page_name=profile&id=<?=$user['id']?>">
                    <img src="<?=crop($user['image'],400,$user['gender'])?>" alt="<?=esc($user['username'])?>">
                </a>
                <h4>
                    <a href="index.php?page_name=profile&id=<?=$user['id']?>" style="color: #6f4c3e; text-decoration: none;"><?=esc($user['username'])?></a>
                </h4>
                <p>Gender: <?=esc($user['gender'])?></p>
                <p>Email: <?=esc($user['email'])?></p>
                <p>Role: <?=esc($user['role'])?></p>
                <p>Date: <?=date("jS M, Y", strtotime($user['date']))?></p>
                <div>
                    <a href="index.php?page_name=edit-user&id=<?=$user['id']?>">
                        <button class="btn btn-success btn-sm">Edit</button>
                    </a>
                    <a href="index.php?page_name=delete-user&id=<?=$user['id']?>">
                        <button class="btn btn-danger btn-sm">Delete</button>
                    </a>
                    

                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No users found.</p>
    <?php endif; ?>
</div>
