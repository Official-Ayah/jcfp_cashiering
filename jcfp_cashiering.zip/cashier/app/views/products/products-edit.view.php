<?php 
require views_path('partials/header'); 

$db = new Database(); 

// Get Product ID from URL
$id = $_GET['id'] ?? 0;
if ($id == 0) {
    die("Product ID not found!");
}

// Fetch product details
$row = $db->query("SELECT * FROM products WHERE id = ?", [$id]);
$row = $row ? $row[0] : null;

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Retrieve form data
    $description = $_POST['description'] ?? '';
    $category = $_POST['category'] ?? '';
    $qty = $_POST['qty'] ?? 1;
    $amount = $_POST['amount'] ?? 0.00;

    // Handle Image Upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $imageName = time() . '_' . $_FILES['image']['name'];
        $imagePath = 'uploads/' . $imageName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            $image = $imageName;
        } else {
            $errors['image'] = "Image upload failed!";
        }
    }

    // Update Query
      $query = "UPDATE products SET 
                description = ?, 
                category = ?, 
                qty = ?, 
                amount = ?, 
                image = ? 
              WHERE id = ?";
    $params = [$description, $category, $qty, $amount, $image, $id];

    $updateSuccess = $db->query($query, $params);

    if ($updateSuccess) {
        echo "<script>
                alert('Product updated successfully!');
                window.location.href='index.php?page_name=admin&tab=products';
              </script>";
        exit;
    } else {
        echo "<script>alert('Update failed! Please try again.');</script>";
    }
}
?>

<div class="container-fluid border rounded p-4 m-2 col-lg-4 mx-auto">
    <?php if (!empty($row)): ?>
        <form method="post" enctype="multipart/form-data">
            <h5><i class="fa fa-box-open"></i> Edit Product</h5>
            <br>

            <div class="mb-3">
                <label for="productControlInput1" class="form-label">Product Description</label>
                <input value="<?= htmlspecialchars($row['description']) ?>" name="description" type="text" class="form-control" id="productControlInput1" required>
            </div>

            <div class="mb-3">
            <div class="mb-3">
    <label for="category" class="form-label">Category</label>
    <select name="category" id="category" class="form-control" required>
        <option value="classic-milkteas" <?= $row['category'] == 'Classic Milkteas' ? 'selected' : '' ?>>Classic Milkteas</option>
        <option value="fruit-teas" <?= $row['category'] == 'Fruit Teas' ? 'selected' : '' ?>>Fruit Teas</option>
        <option value="special-series" <?= $row['category'] == 'Special Series' ? 'selected' : '' ?>>Special Series</option>
        <option value="bar-snacks" <?= $row['category'] == 'Bar Snacks' ? 'selected' : '' ?>>Bar Snacks</option>
        <option value="cold-coffee" <?= $row['category'] == 'Cold Coffee' ? 'selected' : '' ?>>Cold Coffee</option>
        <option value="milk-based" <?= $row['category'] == 'Milk Based' ? 'selected' : '' ?>>Milk Based</option>
        <option value="soda-based" <?= $row['category'] == 'Soda Based' ? 'selected' : '' ?>>Soda Based</option>
    </select>
</div>

            <div class="mb-3">
                <label for="amount" class="form-label">Amount</label>
                <input name="amount" value="<?= htmlspecialchars($row['amount']) ?>" step="0.05" type="number" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="formFile" class="form-label">Product Image</label>
                <input name="image" class="form-control" type="file" id="formFile">
                <br>
                <img class="mx-auto d-block" src="uploads/<?= htmlspecialchars($row['image']) ?>" style="width: 30%;">
            </div>

            <br>
            <button class="btn btn-danger float-end">Save</button>

            <a href="index.php?page_name=admin&tab=products">
                <button type="button" class="btn btn-primary">Cancel</button>
            </a>
        </form>
    <?php else: ?>
        <p>That product was not found.</p>
        <br>
        <a href="index.php?page_name=admin&tab=products">
            <button type="button" class="btn btn-primary">Back to Products</button>
        </a>
    <?php endif; ?>
</div>

<?php require views_path('partials/footer'); ?>
