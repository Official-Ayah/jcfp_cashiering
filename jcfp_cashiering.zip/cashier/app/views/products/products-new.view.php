<?php
require views_path('partials/header');

$db = new Database(); // Instantiate Database class
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $description = $_POST['description'] ?? '';
    $category = $_POST['category'] ?? '';
    $amount = $_POST['amount'] ?? 0.00;
    $quantity = $_POST['quantity'] ?? 1;
    $user_id = null; // Set user_id as NULL unless a session/user authentication exists
    $views = 0; // Default value for views

    // Handle image upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $imageName = time() . '_' . $_FILES['image']['name'];
        $imagePath = 'uploads/' . $imageName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            $image = $imageName;
        } else {
            $errors['image'] = "Image upload failed!";
        }
    }

    if (empty($description)) $errors['description'] = "Product description is required.";
    if (empty($category)) $errors['category'] = "Category is required.";
    if ($amount <= 0) $errors['amount'] = "Amount must be greater than 0.";
    if ($quantity < 1) $errors['quantity'] = "Quantity must be at least 1.";

    if (empty($errors)) {
        $query = "INSERT INTO products (user_id, description, category, amount, image, date, views) 
                  VALUES (:user_id, :description, :category, :amount, :image, NOW(), :views)";
        
        $params = [
            ':user_id' => $user_id,
            ':description' => $description,
            ':category' => $category,
            ':amount' => $amount,
            ':image' => $image,
            ':views' => $views
        ];

        if ($db->query($query, $params)) {
            echo "<script>alert('Product added successfully!'); window.location.href='index.php?page_name=admin&tab=products';</script>";
            
            exit;
        } else {
            $errors['database'] = "Failed to add product.";
        }
    }
}
?>

<div class="container-fluid border rounded p-4 m-2 col-lg-4 mx-auto">
    <form method="post" enctype="multipart/form-data">
        <h5><i class="fa fa-tags"></i> Add Product</h5>
        <br>

        <div class="mb-3">
            <label for="productControlInput1" class="form-label">Product Description</label>
            <input name="description" type="text" class="form-control" id="productControlInput1" placeholder="Product description">
            <?php if (!empty($errors['description'])): ?> 
                <small class="text-danger"><?= $errors['description'] ?></small>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="category" class="form-label">Category</label>
            <select name="category" id="category" class="form-control" required>
                <option value="Classic Milkteas">Classic Milktea</option>
                <option value="Fruit Teas">Fruit Tea</option>
                <option value="Special Series">Special Series Milktea</option>
                <option value="Bar Snacks">Bar Snacks</option>
                <option value="Cold Coffee">Cold Coffee</option>
                <option value="Milk Based">Milk Based</option>
                <option value="Soda Based">Soda Based</option>
            </select>
            <?php if (!empty($errors['category'])): ?> 
                <small class="text-danger"><?= $errors['category'] ?></small>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="amount" class="form-label">Amount</label>
            <input name="amount" value="0.00" step="0.05" type="number" class="form-control" placeholder="Amount">
            <?php if (!empty($errors['amount'])): ?> 
                <small class="text-danger"><?= $errors['amount'] ?></small>
            <?php endif; ?>
            </div>

        <div class="mb-3">
            <label for="formFile" class="form-label">Product Image</label>
            <input name="image" class="form-control" type="file" id="formFile">
            <?php if (!empty($errors['image'])): ?> 
                <small class="text-danger"><?= $errors['image'] ?></small>
            <?php endif; ?>
        </div>

        <button class="btn btn-danger float-end" type="submit">Save</button>
        <a href="index.php?page_name=admin&tab=products">
            <button type="button" class="btn btn-primary">Cancel</button>
        </a>
    </form>
</div>

<?php require views_path('partials/footer'); ?>
