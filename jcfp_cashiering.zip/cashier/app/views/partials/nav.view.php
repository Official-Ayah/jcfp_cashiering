<nav class="navbar navbar-expand-lg" style="background: linear-gradient(90deg, #6B4226, #8B5A2B); min-width: 350px; border-radius: 5px; box-shadow: 0px 4px 6px rgba(0,0,0,0.1);">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php?page_name=home" style="font-weight: bold; font-size: 1.6rem; color: #fff; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);">
            JCFP Milktea
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="background-color: #fff; width: 25px; height: 25px; border-radius: 50%;"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarContent" style="flex-grow: 1; justify-content: space-between;">
            <ul class="navbar-nav me-auto">
                <?php if(Auth::access('supervisor')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page_name=admin" style="color: #fff; font-weight: 500; padding: 10px 20px; text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);">Admin</a>
                    </li>
                <?php endif; ?>

                <?php if(!Auth::logged_in()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page_name=login" style="color: #fff; font-weight: 500; padding: 10px 20px; text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);">Login</a>
                    </li>
                <?php endif; ?>
            </ul>

            <?php if(Auth::logged_in()): ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item" style="color: #fff; padding-right: 15px; margin-top: 5px;">
                        Hi, <?= auth('username') ?> (<?= Auth::get('role') ?>)
                    </li>
                    <li class="nav-item">
                        <a class="nav-link logout-btn" href="index.php?page_name=logout">Logout</a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Inline CSS for responsiveness and hover effects -->
<style>
    /* Responsive styles */
    @media (max-width: 768px) {
        .navbar-brand {
            font-size: 1.3rem;
        }

        .nav-link, .nav-item {
            text-align: center;
        }

        .nav-item .nav-link {
            display: block;
            margin-top: 10px;
        }
    }

    /* Hover effect for navigation links */
    .nav-item .nav-link:hover {
        background-color: rgba(255, 255, 255, 0.1);
        color: #fff;
        border-radius: 10px;
        transition: all 0.3s ease-in-out;
    }

    /* Logout button styling */
    .logout-btn {
        color: #fff;
        background-color: #D66A2C; /* Improved logout button color */
        border-radius: 15px;
        padding: 6px 18px;
        font-weight: bold;
        transition: background-color 0.3s ease-in-out;
    }

    .logout-btn:hover {
        background-color: #B7511D;
    }
</style>
