<?php require views_path('partials/header');?>

    <br>
        <center>
            <h1>Access Denied!</h1>
            <div><?=Auth::getMessage()?></div>
        </center>
    <br>

<?php require views_path('partials/footer');?>
