<?php require views_path('partials/header'); ?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

body {
    font-family: 'Poppins', sans-serif;
    background: url('uploads/background.jpg') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Centering Container */
.container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    position: relative;
}

/* Login Card */
.card {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 30px;
    gap: 15px;
    background: rgba(255, 255, 255, 0.95); /* Less transparency */
    box-shadow: 8px 8px 25px rgba(0, 0, 0, 0.2);
    border-radius: 12px;
    width: 420px;
    min-height: 420px;
    backdrop-filter: blur(8px); /* Glass effect */
}

/* Login Heading */
.login {
    font-size: 1.8rem;
    font-weight: 600;
    color: #6f4c3e;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 10px;
}

/* Input Box */
.inputBox {
    position: relative;
    width: 100%;
    margin-bottom: 15px;
}

.inputBox input {
    width: 100%;
    padding: 12px;
    outline: none;
    border: none;
    font-size: 1rem;
    background: white;
    border: 2px solid #6f4c3e;
    border-radius: 8px;
    transition: 0.3s ease-in-out;
}

.inputBox input:focus {
    border: 2px solid #5b3d30;
    box-shadow: 0px 0px 10px rgba(111, 76, 62, 0.5);
}

/* Placeholder Animation */
.inputBox label {
    position: absolute;
    top: 50%;
    left: 15px;
    font-size: 0.9rem;
    color: #6f4c3e;
    transition: 0.3s ease-in-out;
    transform: translateY(-50%);
}

.inputBox input:focus ~ label,
.inputBox input:valid ~ label {
    top: -10px;
    left: 10px;
    font-size: 0.8rem;
    background: white;
    padding: 2px 5px;
    border-radius: 5px;
    color: #5b3d30;
}

/* Login Button */
.btn-primary {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    font-weight: bold;
    background: #6f4c3e;
    color: white;
    border: none;
    border-radius: 8px;
    transition: 0.3s ease-in-out;
    cursor: pointer;
}

.btn-primary:hover {
    background: #5b3d30;
    transform: scale(1.05);
}

/* Error Message */
.text-danger {
    font-size: 0.85rem;
    color: #d9534f;
}

/* JCFP Milktea Title */
.milktea-title {
    position: absolute;
    top: -20%; /* Moves the title higher */
    left: 50%;
    transform: translateX(-50%);
    font-size: clamp(3rem, 4vw, 4.5rem);
    font-weight: 700;
    color: #fff;
    text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.8);
    letter-spacing: 2px;
    animation: fadeInUp 0.8s ease-out;
    white-space: nowrap;
    z-index: 10; /* Ensures it stays on top */
}

.card {
    position: relative; /* Prevents overlap issues */
    z-index: 5; /* Places form below title */
}



</style>

<div class="container">
    <div class="card">
        <a class="login">Login</a>
        <form method="post">

        <div class="form-floating">
          <input autocomplete="off" name="email" type="email" class="form-control" id="email" placeholder="Email address" autofocus>
          <label for="email">Email address</label>
          <?php if (!empty($errors['email'])): ?> 
          <small class="text-danger"><?=$errors['email']?></small>
       <?php endif; ?>
       </div>

        <div class="form-floating mt-2">
           <input name="password" type="password" class="form-control" id="password" placeholder="Password">
           <label for="password">Password</label>
         <?php if (!empty($errors['password'])): ?> 
         <small class="text-danger"><?=$errors['password']?></small>
        <?php endif; ?>
       </div>
            <br>
            <div class="inputBox">
                <button type="submit" class="btn btn-primary w-100">Login</button> <!-- Added type="submit" -->
            </div>
        </form>
    </div>
    <div class="milktea-title">JCFP
         Milktea</div>
</div>


<?php require views_path('partials/footer'); ?>
