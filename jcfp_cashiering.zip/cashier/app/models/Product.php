<?php

class Product extends Model
{
    protected $table = "products";
    protected $allowed_columns = [
        'user_id',
        'description',
        'category', // Added category field
        'amount',
        'image',
        'date',
        'views',
    ];

    public function validate($data, $id = null)
    {
        $errors = [];

        // Check description
        if (empty($data['description'])) {
            $errors['description'] = "Product description is required";
        } elseif (!preg_match('/[a-zA-Z0-9 _\-\&\(\)]+/', $data['description'])) {
            $errors['description'] = "Only letters, numbers, and certain symbols allowed in description";
        }

        // Check category
        if (empty($data['category'])) {
            $errors['category'] = "Category is required";
        } else {
            // Define allowed categories (adjust based on your needs)
            $allowed_categories = ['classic', 'fruit', 'special', 'snacks', 'cold', 'milk', 'soda'];

            if (!in_array(strtolower($data['category']), $allowed_categories)) {
                $errors['category'] = "Invalid category selected";
            }
        }

        // Check qty
        if (empty($data['qty'])) {
            $errors['qty'] = "Product quantity is required";
        } elseif (!preg_match('/^[0-9]+$/', $data['qty'])) {
            $errors['qty'] = "Quantity must be a number";
        }

        // Check amount
        if (empty($data['amount'])) {
            $errors['amount'] = "Product amount is required";
        } elseif (!preg_match('/^[0-9.]+$/', $data['amount'])) {
            $errors['amount'] = "Amount must be a valid number";
        }

        // Check image
        $max_size = 4; // 4MB limit
        $size = $max_size * (1024 * 1024);

        if (!$id || ($id && !empty($data['image']))) {
            if (empty($data['image'])) {
                $errors['image'] = "Product image is required";
            } elseif ($data['image']['error'] > 0) {
                $errors['image'] = "The image failed to upload. Error No." . $data['image']['error'];
            } elseif ($data['image']['size'] > $size) {
                $errors['image'] = "The image size must be lower than " . $max_size . "MB";
            }
        }

        return $errors;
    }

    public function generate_filename($ext = "jpg")
    {
        return hash("sha1", rand(1000, 999999999)) . "_" . rand(1000, 9999) . "." . $ext;
    }
}
